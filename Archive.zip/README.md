# **Mute words on facebook newsfeed!**

A chrome extension to mute words on facebook to hide posts on your newsfeed contains the specific words.

You can try it here: [Mute Words Chrome Extension](https://chrome.google.com/webstore/detail/mute-words-on-facebook/fhcioeahbcdffnkfgkbgghgdchbokohh).

## [Special Releases](https://github.com/zeyadetman/mutewords/releases)

## Contributors

- [@zeyadetman](https://twitter.com/zeyadetman)
- [@mohamedgomran](https://github.com/mohamedgomran)
